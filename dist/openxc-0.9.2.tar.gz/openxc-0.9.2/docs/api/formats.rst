============
Data Formats
============

.. automodule:: openxc.formats.json
    :members:
    :undoc-members:
