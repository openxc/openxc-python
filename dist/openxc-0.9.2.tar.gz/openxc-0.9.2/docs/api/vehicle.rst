======================
Vehicle functions
======================

.. automodule:: openxc.vehicle
    :members:
    :undoc-members:
