==========
Units
==========

.. automodule:: openxc.units

.. autoclass:: Percentage
.. autoclass:: Meter
.. autoclass:: Kilometer
.. autoclass:: Hour
.. autoclass:: KilometersPerHour
.. autoclass:: RotationsPerMinute
.. autoclass:: Litre
.. autoclass:: Degree
.. autoclass:: NewtonMeter
.. autoclass:: MetersPerSecondSquared
.. autoclass:: Undefined
