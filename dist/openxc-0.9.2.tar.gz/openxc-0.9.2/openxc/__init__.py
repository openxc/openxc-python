import openxc.logconfig
